import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import firebase from "firebase";
import reportWebVitals from './reportWebVitals';

//const firebase = require('firebase');
require('firebase/firestore');

const firebaseConfig = {
    apiKey: "AIzaSyBI6OFjzuJWQ1Qsz8ij_sk0SwID1KWDwN8",
    authDomain: "notemaker-51edc.firebaseapp.com",
    databaseURL: "https://notemaker-51edc.firebaseio.com",
    projectId: "notemaker-51edc",
    storageBucket: "notemaker-51edc.appspot.com",
    messagingSenderId: "852785855923",
    appId: "1:852785855923:web:b755c75618b2e9b5695fc6",
    measurementId: "G-71Z26Z6ZN4"
  };
  // Initialize Firebase
firebase.initializeApp(firebaseConfig);

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('notemaker-container')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
